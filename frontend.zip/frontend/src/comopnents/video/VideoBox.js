import React, { useEffect,useState,useRef } from "react";
import './VideoBox.css'

export default function (props) {



  

    return (
        <>

        </>
    );
}