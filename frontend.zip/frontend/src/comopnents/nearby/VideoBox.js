import './VideoBox.css'

export default function(props){
    return(
        <>
            <div className='videoBoxCont'>
                <div className="liveVideoCont strangerLiveVideoCont">
                    
                </div>
                <div className="liveVideoCont userLiveVideoCont">

                </div>
            </div>
        </>
    );
}